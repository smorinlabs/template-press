"""Summarize the downloaded Windows runner experiment without changing inputs."""

import hashlib
import json
import statistics
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROTOCOL = json.loads((ROOT / "protocol.json").read_text())
MATCHED_STEPS = (
    "Run actions/checkout@v7",
    "Install uv",
    "Install bun (pinned for native R3)",
    "Sync dev env",
    "Run edit visibility regressions first",
    "Run tests with coverage",
)


def seconds(item: dict[str, str]) -> float:
    return (
        datetime.fromisoformat(item["completed_at"])
        - datetime.fromisoformat(item["started_at"])
    ).total_seconds()


jobs = json.loads((ROOT / "jobs.json").read_text())["jobs"]
rows = []
for job in sorted(jobs, key=lambda value: value["name"]):
    if job["conclusion"] != "success":
        rows.append({"job": job["name"], "conclusion": job["conclusion"]})
        continue
    sample, vcpu = [int(word) for word in job["name"].split() if word.isdigit()]
    matches = list((ROOT / "artifacts").glob(f"{vcpu}c-{sample}-*"))
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one artifact for {job['name']}: {matches}")
    artifact = matches[0]
    results = artifact / "ci-results"
    runner = json.loads((results / "runner.json").read_text(encoding="utf-8-sig"))
    runtime = json.loads((results / "full/runtime.json").read_text())
    assert runner["source_revision"] == PROTOCOL["source_revision"]
    assert runtime["source_revision"]["output"] == PROTOCOL["source_revision"]
    assert runner["actual_vcpu"] == vcpu == runtime["cpu_count"]
    assert runner["blueprint_before"].strip() == (
        results / "blueprint-after.txt"
    ).read_text(encoding="utf-8-sig").strip()
    assert runtime["returncode"] == 0
    full = ET.parse(results / "full.xml").getroot()
    suites = list(full.iter("testsuite"))
    counts = {
        name: sum(int(suite.attrib.get(name, "0")) for suite in suites)
        for name in ("tests", "failures", "errors", "skipped")
    }
    identities = sorted(
        (case.attrib["classname"], case.attrib["name"])
        for case in full.iter("testcase")
    )
    identity_hash = hashlib.sha256(json.dumps(identities).encode()).hexdigest()
    steps = {step["name"]: step for step in job["steps"]}
    step_seconds = {name: seconds(steps[name]) for name in MATCHED_STEPS}
    worker_counts = set()
    for journal in (results / "full").glob("progress-*.jsonl"):
        for line in journal.read_text().splitlines():
            entry = json.loads(line)
            if entry.get("worker_count", 0):
                worker_counts.add(entry["worker_count"])
    coverage = ET.parse(artifact / "coverage.xml").getroot().attrib
    rows.append(
        {
            "job": job["name"],
            "job_id": job["id"],
            "job_url": job["html_url"],
            "conclusion": job["conclusion"],
            "sample": sample,
            "vcpu": vcpu,
            "runner": runner,
            "runtime_python": runtime["python"],
            "runtime_tools": {name: runtime[name] for name in ("uv", "git", "bun")},
            "worker_counts": sorted(worker_counts),
            "test_counts": counts,
            "test_identity_sha256": identity_hash,
            "coverage_line_rate": float(coverage["line-rate"]),
            "coverage_branch_rate": float(coverage["branch-rate"]),
            "step_seconds": step_seconds,
            "full_suite_seconds": step_seconds["Run tests with coverage"],
            "pytest_wrapper_seconds": runtime["finished_at"] - runtime["started_at"],
            "matched_workload_seconds": sum(step_seconds.values()),
            "total_job_seconds": seconds(job),
            "exceeds_production_test_timeout": (
                step_seconds["Run tests with coverage"]
                > PROTOCOL["production_full_suite_timeout_seconds"]
            ),
        }
    )

complete = [row for row in rows if row["conclusion"] == "success"]
groups = {}
for vcpu in (4, 2):
    samples = [row for row in complete if row["vcpu"] == vcpu]
    if not samples:
        continue
    metrics = {}
    for metric in ("full_suite_seconds", "matched_workload_seconds", "total_job_seconds"):
        values = [row[metric] for row in samples]
        metrics[metric] = {
            "median": statistics.median(values),
            "min": min(values),
            "max": max(values),
        }
    groups[vcpu] = {"samples": len(samples), "metrics": metrics}

comparison = {}
if 2 in groups and 4 in groups:
    for metric in ("full_suite_seconds", "matched_workload_seconds", "total_job_seconds"):
        candidate = groups[2]["metrics"][metric]["median"]
        baseline = groups[4]["metrics"][metric]["median"]
        comparison[metric] = {
            "additional_seconds": candidate - baseline,
            "slowdown_percent": 100 * (candidate / baseline - 1),
            "estimated_cost_savings_percent": 100 * (1 - 0.5 * candidate / baseline),
        }

summary = {
    "samples": rows,
    "same_test_identities": len({row["test_identity_sha256"] for row in complete}) == 1,
    "same_test_counts": len({json.dumps(row["test_counts"]) for row in complete}) == 1,
    "groups": groups,
    "comparison": comparison,
}
(ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({key: value for key, value in summary.items() if key != "samples"}, indent=2))
for row in rows:
    print(json.dumps({key: value for key, value in row.items() if key not in {"runner", "runtime_tools", "step_seconds"}}))
